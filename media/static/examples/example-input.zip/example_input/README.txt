Example input for DREEM server

test.fasta -> example fasta file to be uploaded under "Fasta file". Contains a single RNA sequence converted to DNA. 
 
test_mate1.fastq -> example forward fastq file to be uploaded under "Fastq1 file". This contains raw sequencing reads that contain the RNA in the 5' to 3' direction.

test_mate2.fastq -> example reverse fastq file to be uploaded under "Fastq2 file" This contains raw sequencing reads that contain the reverse complement of the target RNA.
